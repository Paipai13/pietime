/*
 * Copyright 2018 Amazon.com, Inc. and its affiliates. All Rights Reserved.
 * Licensed under the Amazon Software License (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * http://aws.amazon.com/asl/
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
 
const Alexa = require('ask-sdk');

/////////1. Static strings///////////////////////////////////Modify the hard coded data below to make this skill your own!///
//Skill data
var skillName = 'Pie Time';
var skillQuizName = 'Pies on the Fly';
var skillDictionaryName = 'ReciPie Book';
var categoryPlural = 'pies';
var categorySingular = 'pie';

var mainImage = 'https://s3.amazonaws.com/pietime/americanpie.jpg';
var mainImgBlurBG = 'https://s3.amazonaws.com/pietime/kitchn.jpg';

var topicData = {
    "Raspberry Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/rasppie.jpg",
        "info": "You will need: 9 inch double crust pie, 4 cups rasppies, 1 cup white sugar, 2 1/2 tablespoons tapioca, 1 tablespoon lemon juice, 1/4 teaspoon ground cinnamon. 1/8 teaspoon salt, 4 teaspoons butter, 1 tablespoon half-and-half cream. To Cook: Preheat the oven to 425*F. Mix ingredients except butter. Butter the Pie crust, Pour into pie crust. Cook for 15 Minutes. Cool to 375*F for 25 Minutes."
    },
    "Blackberry Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/blackpie.jpg",
        "info": "You will need: 4 cups fresh blackpies, 1/2 cup white sugar, 1/2 cup all-purpose flour, 9 inch double crust pie, 2 tablespoons milk, 1/4 cup white sugar. To Cook: Preheat oven to 425*. Mix pies, Sugar and Flour, Brush Milk and 1/4 Sugar on pie crust.Cook for 15 Minutes. Cool Down to 375*F for 25 Minutes "
    },
    "Strawberry Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/strawpie.jpg",
        "info": "You will need: 9 inch pie shell, 3/4 cup sugar, 2 tablespoons cornstarch, 1 cup water, 1 package strawberry Jello, 4 cups sliced fresh strawpies. To Cook: Preheat oven to 450*F. Wrap pie shell in foil. Place wrapped shell in oven for 8 Minutes. Remove foil. Bake more for 5 minutes. Combine Sugar, Water and cornstarch into a sauce pan. Bring to a boil and stir for 2 Minutes. Stir in Jello until dissolved. Refrigerate for 20 Minutes. Arrange Strawpies in crust, and pour mixture. Refrigerate until set."
    },
    "Blueberry Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/bluepie.jpg",
        "info": "You will need: 3/4 cup white sugar, 3 tablespoons cornstarch, 1/4 teaspoon salt, 1/2 teaspoon ground cinnamon, 4 cups fresh bluepies, 9 inch double crust pie, 1 tablespoon butter. To Cook: Preheat oven to 375*F. Mix Cinnamon, Cornstarch, Sugar, and salt. Pour over Bluepies. Pour into Crust an dot with Butter. Cook for 50 Minutes."
    },
    "Apple Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/applepie.jpg",
        "info": "You will need: 1/2 cup sugar, 1/2 cup packed brown sugar, 3 tablespoons all-purpose flour, 1 teaspoon ground cinnamon, 1/4 teaspoon ground ginger, 1/4 teaspoon ground nutmeg, 6 to 7 cups thinly sliced peeled tart apples, 1 tablespoon lemon juice, 9 inch pie crust, 1 tablespoon butter, 1 large egg white, Pinch of sugar. To Cook: Mix Sugar, Flour, and Spices. Toss Apples in Lemon Juice and Dry ingrediant Mix. Fill Pie crust with mixture. Brush with egggwash. dot with butter. Wrap in foil. Bake at 375*F for 25 Minutes. Remove foil. Bake for 25 minutes."
    },
    "Chocolate Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/ChocoPie.jpg",
        "info": "You will need: 1 can (12 oz each) evaporated milk, 1 pkg (5.9 oz each) chocolate instant pudding mix, 1 can (6.5 oz each) Reddi-wip® Original Dairy Whipped Topping, 1/2 cup mini semisweet chocolate morsels, 1 graham cracker pie crust (9-inch). To Cook: Mix Milk, Morsels, and Pudding Mix. Pour into pie crust and put in fridge to set for 6 hours"
    },
    "Cherry Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/Cherrypie.jpg",
        "info": "You will need: 1 box Pillsbury™ refrigerated pie crusts, softened as directed on box, 2 cans (21 oz each) cherry pie filling, 1 teaspoon milk, 1 teaspoon sugar. To Cook: Preheat to 425*F. Spoon in Cherry filling onto bottom crust, Place other pie crust on top of pie. cut slits onto top crust. Brush top crust with milk. Put in oven for 40-45 minutes."
    },
    "Pecan Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/pe-can-d0+pie.jpg",
        "info": "You will need: 1 cup packed brown sugar, 1/3 cup butter melted, 3/4 cup light corn syrup, 1/2 teaspoon salt, 3 eggs, 1 1/2 cups pecan halves or pieces, 1 12 inch pie crust. To Cook: Preheat oven to 375*F. Mix in all ingredients. Pour onto pie crust. bake for 35-45 minutes. Once done, chill 2 hours before serving."
    },
    "Pumpkin Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/Pumpkin+Pie.jpg",
        "info": "3/4 cup sugar, 1 1/2 teaspoons pumpkin pie spice, 1/2 teaspoon salt, 1 can (15 oz) pumpkin, 1 1/4 cups evaporated milk or half and half, 2 beaten eggs, 1 deep-dish pie crust. To Cook: Preheat oven to 425*F. Mix Ingrediants. Pour into pie crust. Cook for 15 Minutes. Reduce temp to 350*F. Bake till knife comes out clean (Aprox. 40-50 min)"
    },
    "Banana Split Pie": {
        "imgURL": "https://s3.amazonaws.com/pietime/BSP.jpg",
        "info": "What you need: 2 pkg JELL-O Vanilla Pudding, 2 cups cold milk, 1 ready-to-use graham cracker crust (6 oz.), 1 banana, sliced, 1 cup sliced fresh strawpies divided, 1 can of pineapple, 1 tub (8 oz.) COOL WHIP thawed, divided, 2 Tbsp. chocolate syrup, 1/4 cup chopped Pecans. To Cook: Make pudding. Mix in pineapple, bananas, 1/2 of cool whip, and 1/2 of strawpies. Top with rest of Cool Whip, rest of Strawpies, Chocolate syrup, and Pecans. Chill in the fridge for 3 hours."
    }
}

var adjectives = ['craziest', 'hippest', 'tastiest', 'sweetest', 'greatest', 'cheekiest', 'spiciest', 'greatest', 'smartest', 'best'];

var positiveSpeechconArray = ['bang', 'boing', 'kaboom', 'mazel tov', 'oh snap', 'well done'];
var negativeSpeechconArray = ['wah wah', 'uh oh', 'tosh', 'quack', 'oof', 'oh dear'];

var correctResponses = ['That is correct.', 'You got it!', 'Nice one.', 'There you go.', 'Awesome', 'Congratulations.'];
var wrongResponses = ['Oh no.', 'That is wrong.', 'Incorrect.', 'Unlucky.', 'Maybe next time.', 'Nearly.'];

var secondPlaceImage = 'https://s3.amazonaws.com/ask-samples-resources/berryImages/medal-2163349_640.png';
var firstPlaceImage = 'https://s3.amazonaws.com/ask-samples-resources/berryImages/medal-2163347_640.png';

const GAMELENGTH = 5;
var testingOnSim = false; //flip to experience voice only skill on display device/simulator

/////////2. Entry point and intent handlers//////////////////////////////////////////////////////////////////////////
const skillBuilder = Alexa.SkillBuilders.standard();

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === `LaunchRequest`;
    },
    handle(handlerInput) {

        newSessionHandler(handlerInput);

        var speechOutput = 'Welcome to ' + skillName + ', the ' + adjectives[getRandomVal(0, adjectives.length - 1)] + ' stop for knowledge about ' + categoryPlural + ' around. ';
        var reprompt = "What would you like to do?";

        return showSkillIntro(speechOutput, reprompt, handlerInput);
    },
};

const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

        //User has outright quit the skill
        return endSkill(handlerInput);
    },
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`Error handled: ${error.message}`);

        return handleUnknown(handlerInput);
    },
};

const PreviousIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.PreviousIntent';
    },
    handle(handlerInput) {
        var speechOutput;
        var reprompt;
        const attributes = handlerInput.attributesManager.getSessionAttributes();

        //If we are showing a fruit, go back to the main list
        if (attributes.selectedValueIndex) {
            return showMainList(handlerInput);
        } else if (attributes.skillState == 'gamePlaying') {
            speechOutput = 'You are currently in the middle of a game. Would you like to carry on playing?';
            reprompt = 'Would you like to carry on playing?';

            saveLastThingSaid(handlerInput, speechOutput);

            const response = handlerInput.responseBuilder;

            return response
                .speak(speechOutput)
                .reprompt(reprompt)
                .getResponse();
        } else {
            return showSkillIntro(speechOutput, reprompt, handlerInput);
        }
    },
};

function QuizFunction(handlerInput) {
    newSessionHandler(handlerInput);
    var speechOutput;
    var reprompt;

    resetAttributes(handlerInput);

    const attributes = handlerInput.attributesManager.getSessionAttributes();

    const response = handlerInput.responseBuilder;

    if (attributes.skillState != 'gamePlaying') {
        if (supportsDisplay(handlerInput) && !testingOnSim) {
            speechOutput = '<say-as interpret-as="interjection">dun dun dun.</say-as> Check out the big brains over here. Are you ready to begin?';
            reprompt = "Are you ready to begin?";

            attributes.quizArray = attributes.mainArray;
            attributes.skillState = 'quizMainMenu';

            handlerInput.attributesManager.setSessionAttributes(attributes);

            return bodyTemplateMaker('BodyTemplate7', handlerInput, mainImage, 'Time to play ' + skillQuizName + '!', null, null, null, speechOutput, reprompt, null, mainImgBlurBG, false);
        } else {
            speechOutput = 'Unfortunately, ' + skillQuizName + ' is not supported on this device, but you can still learn about the wonder of penguins which in my opinion is far more fun. What would you like to do?';
            reprompt = 'What would you like to do?';

            saveLastThingSaid(handlerInput, speechOutput)

            return response.speak(speechOutput).reprompt(reprompt).getResponse();
        }
    } else if (supportsDisplay.call(this) && !testingOnSim) {
        speechOutput = 'You are already in the middle of a game. Please answer the question: ' + attributes.storedQuestion;


        response.withShouldEndSession(null);

        saveLastThingSaid(handlerInput, speechOutput);

        return response.speak(speechOutput).getResponse();
    }
}

const QuizIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'QuizIntent';
    },
    handle(handlerInput) {
        return QuizFunction(handlerInput);
    },
};

const MoreInfoIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'MoreInfoIntent';
    },
    handle(handlerInput) {
        const attributes = handlerInput.attributesManager.getSessionAttributes();

        if (attributes.selectedValueIndex) {
            var objectArray = attributes.mainArray;
            var selectedVal = attributes.selectedValueIndex;
            var speechOutput = objectArray[selectedVal].info;

            const response = handlerInput.responseBuilder;

            response.withShouldEndSession(null);

            saveLastThingSaid(handlerInput, speechOutput);

            return response.speak(speechOutput).getResponse();
        } else {
            return handleUnknown(handlerInput);
        }
    },
};

const RepeatIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.RepeatIntent';
    },
    handle(handlerInput) {

        const attributes = handlerInput.attributesManager.getSessionAttributes();

        var speechOutput = attributes.lastOutputResponse;

        const response = handlerInput.responseBuilder;

        response.withShouldEndSession(null);

        saveLastThingSaid(handlerInput, speechOutput);

        return response.speak(speechOutput).getResponse();
    },
};

const StopIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.StopIntent';
    },
    handle(handlerInput) {


        return endSkill(handlerInput);
    },
};

const CancelIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.CancelIntent';
    },
    handle(handlerInput) {
        //Provide instructions based on skill state
        newSessionHandler(handlerInput);

        return endSkill(handlerInput);
    },
};

const InformationIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'InformationIntent';
    },
    handle(handlerInput) {
        var speechOutput;
        var reprompt;

        newSessionHandler(handlerInput);

        const attributes = handlerInput.attributesManager.getSessionAttributes();
        if (attributes.skillState == 'gamePlaying') {
            speechOutput = 'You are currently in the middle of a game. Would you like to carry on playing?';
            reprompt = 'Would you like to keep on playing?';
            saveLastThingSaid(handlerInput, speechOutput)

            const response = handlerInput.responseBuilder;

            return response
                .speak(speechOutput)
                .reprompt(reprompt)
                .getResponse();
        } else {

            return showMainList(handlerInput);
        }
    },
};

const NextIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.NextIntent';
    },
    handle(handlerInput) {
        //Provide instructions based on skill state
        newSessionHandler.call(this);

        return handleUnknown(handlerInput);
    },
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        //Provide instructions based on skill state
        newSessionHandler.call(this);

        const attributes = handlerInput.attributesManager.getSessionAttributes();
        const response = handlerInput.responseBuilder;

        var speechOutput;
        var reprompt;

        if (attributes.skillState == 'gamePlaying') {
            speechOutput = 'In ' + skillQuizName + ', you simply need to select the option that most resembles the ' + categorySingular + ' being asked for in the question; either say 1 - 4, or touch the screen!';

            response.withShouldEndSession(null);

            saveLastThingSaid(handlerInput, speechOutput);
            response.speak(speechOutput).getResponse();
        } else {
            //const request = handlerInput.requestEnvelope.request;
            //speechOutput += 'Simply ask me to provide information about ' + categoryPlural + ' from the ' + skillDictionaryName + '.'; //TF Addition
            
            return showSkillIntro(speechOutput, reprompt, handlerInput);
        }
    },
};

const ElementSelectedHandler = {
    canHandle(handlerInput) {

        const request = handlerInput.requestEnvelope.request;
        return (request.type === 'IntentRequest' &&
            request.intent.name === 'ElementSelected')
            || request.type === 'Display.ElementSelected';
    },
    handle(handlerInput) {
        newSessionHandler(handlerInput);

        var speechOutput;

        const attributes = handlerInput.attributesManager.getSessionAttributes();
        const response = handlerInput.responseBuilder;

        if (attributes.skillState == 'gamePlaying') {
            var optionsArray = attributes.onScreenOptions;
            var correctQIndex = attributes.correctIndex;
            var quizOptions = attributes.QuizOptionArray;
            var currentQNo = attributes.questionNumber;

            if (handlerInput.requestEnvelope.request.token) {
                //User touched the screen
                if (currentQNo < quizOptions.length - 1) {
                    return handleAnswer(handlerInput, optionsArray[correctQIndex].token, handlerInput.requestEnvelope.request.token, quizOptions, false);
                } else {
                    return handleAnswer(handlerInput, optionsArray[correctQIndex].token, handlerInput.requestEnvelope.request.token, quizOptions, true);
                }
            } else if (handlerInput.requestEnvelope.request.intent.slots.numberValue.value) {
                //User said their choice
                var userChoiceNumber = parseInt(handlerInput.requestEnvelope.request.intent.slots.numberValue.value);

                if (currentQNo < quizOptions.length - 1) {
                    //If still less than the amount of questions left
                    if (userChoiceNumber > 0 && userChoiceNumber < optionsArray.length + 1) {
                        //If their answer is between the amount of options.
                        return handleAnswer(handlerInput, correctQIndex + 1, userChoiceNumber, quizOptions, false);
                    } else {
                        speechOutput = 'Please select a number between 1 and ' + optionsArray.length;

                        response.withShouldEndSession(null);

                        saveLastThingSaid(handlerInput, speechOutput);

                        return response.speak(speechOutput).getResponse();
                    }
                } else {
                    //Game has ended
                    return handleAnswer(handlerInput, correctQIndex + 1, userChoiceNumber, quizOptions, true);
                }
            } else {
                return handleUnknown(handlerInput);
            }
        } else //User is not playing game
        {

            var objectArray = attributes.mainArray;

            //Screen touched
            if (handlerInput.requestEnvelope.request.token) {

                if (handlerInput.requestEnvelope.request.token == "dictionary_token") {
                    //Open dictionary
                    return showMainList(handlerInput);
                } else if (handlerInput.requestEnvelope.request.token == 'quiz_token') {
                    //Start the game
                    return QuizFunction(handlerInput);
                } else if (handlerInput.requestEnvelope.request.token == "read_info_token") {
                    //read out information
                    var selectedIndex = attributes.selectedValueIndex;
                    speechOutput = objectArray[selectedIndex].info;

                    response.withShouldEndSession(null);

                    saveLastThingSaid(handlerInput, speechOutput);

                    return response.speak(speechOutput).getResponse();
                }

                if (handlerInput.requestEnvelope.request.token == "dictionary_token") {
                    //'Go back' action link selectex
                    resetAttributes(handlerInput);
                    return showMainList(handlerInput);
                } else {
                    //Something else selected, most likely from our main list (only list available outside of game)
                    var valueToken = handlerInput.requestEnvelope.request.token;
                    var result = matchChecker(objectArray, valueToken);
                    return showSpecificItemInfo(handlerInput, result, objectArray);
                }
            } else if (handlerInput.requestEnvelope.request.intent.slots.categoryValue.value) {
                //If the user chooses their selection via voice
                resetAttributes(handlerInput);

                var userFruit = handlerInput.requestEnvelope.request.intent.slots.categoryValue.value;
                var iresult = matchChecker(objectArray, userFruit);

                if (iresult) {
                    return showSpecificItemInfo(handlerInput, iresult, objectArray);
                } else {
                    return handleUnknown(handlerInput);
                }
            } else if (handlerInput.requestEnvelope.request.intent.slots.numberValue.value) {
                //If the user chooses their selection via voice
                resetAttributes(handlerInput);

                var userChoiceNumber1 = parseInt(handlerInput.requestEnvelope.request.intent.slots.numberValue.value);

                if (userChoiceNumber1 > 0 && userChoiceNumber1 < objectArray.length + 1) {
                    //If within the range of options offered
                    return showSpecificItemInfo(handlerInput, userChoiceNumber1 - 1, objectArray);
                } else {
                    speechOutput = 'Please say a number between 1 and ' + objectArray.length;

                    response.withShouldEndSession(null);

                    saveLastThingSaid(handlerInput, speechOutput);

                    return response.speak(speechOutput).getResponse();
                }
            } else {
                //If this intent is hit without the needed data
                return handleUnknown(handlerInput);
            }
        }
    },
};

const NoIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.NoIntent';
    },
    handle(handlerInput) {
        newSessionHandler(handlerInput);

        var speechOutput;
        var reprompt;

        const attributes = handlerInput.attributesManager.getSessionAttributes();

        //User wants to stop playing game
        if (attributes.skillState == 'gamePlaying') {
            return showSkillIntro(speechOutput, reprompt, handlerInput);
        } else {
            return endSkill(handlerInput);
        }
    },
};

const YesIntentHandler = {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' &&
            request.intent.name === 'AMAZON.YesIntent';
    },
    handle(handlerInput) {
        newSessionHandler(handlerInput);

        var speechOutput;

        const attributes = handlerInput.attributesManager.getSessionAttributes();

        if (attributes.skillState == 'quizMainMenu') {
            var questionNo = 0;

            speechOutput = '<say-as interpret-as="interjection">Good luck.</say-as> ';

            //Set up new game of quiz
            var objectArray = attributes.quizArray;

            objectArray = shuffle(objectArray);

            var randomObjectArray = [];

            for (let i = 0; i < GAMELENGTH; i++) {
                randomObjectArray[i] = objectArray[i];
            }

            attributes.QuizOptionArray = shuffle(randomObjectArray);
            attributes.skillState = 'gamePlaying';
            handlerInput.attributesManager.setSessionAttributes(attributes);

            return generateNewQuestion(handlerInput, speechOutput, questionNo);
        } else if (attributes.skillState == 'gamePlaying') {
            speechOutput = 'You are currently in the middle of a game. Would you like to carry on playing?';

            const response = handlerInput.responseBuilder;

            saveLastThingSaid(handlerInput, speechOutput)

            return response
                .speak(speechOutput)
                .reprompt(speechOutput)
                .getResponse();
        } else {
            return handleUnknown(handlerInput);
        }
    },
};

exports.handler = skillBuilder
    .addRequestHandlers(
        LaunchRequestHandler,
        InformationIntentHandler,
        YesIntentHandler,
        NoIntentHandler,
        ElementSelectedHandler,
        HelpIntentHandler,
        CancelIntentHandler,
        StopIntentHandler,
        RepeatIntentHandler,
        MoreInfoIntentHandler,
        QuizIntentHandler,
        NextIntentHandler,
        PreviousIntentHandler,
        SessionEndedRequestHandler
    )
    .addErrorHandlers(ErrorHandler)
    .lambda();

////////3. Helper functions//////////////////////////////////////////////////////////////////////////
//Generic functions///////////////////////////////////////////////////////////////////
function matchChecker(pArray, pCompare1) {
    for (let i = 0; i < pArray.length; i++) {
        //Find out which value
        if (pCompare1.toLowerCase() == pArray[i].name.toLowerCase() || pCompare1.toLowerCase() == pArray[i].token.toLowerCase()) {
            //Returns index of match for later use
            return i;
        }
    }
}

function generateRandResponse(pArray, pSpeechCon) {
    var r = getRandomVal(0, pArray.length);

    if (pSpeechCon) {
        return '<say-as interpret-as="interjection">' + pArray[r] + '</say-as>. ';
    } else {
        return pArray[r];
    }
}

function getRandomVal(pMin, pMax) {
    return Math.floor((Math.random() * pMax) + pMin);
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function createArrayValue(pName, pImageURL, pInfo) //object creation
{
    var value = {
        name: pName,
        imageURL: pImageURL,
        info: pInfo,
        token: pName + 'Token',
    };

    return value;
}

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}
//Alexa specific helper functions///////////////////////////////////////////////////////////////////
function showSpecificItemInfo(pHandlerInput, pIndex, pArray) {
    //User has selected a single fruit to get more info
    const attributes = pHandlerInput.attributesManager.getSessionAttributes();
    const response = pHandlerInput.responseBuilder;

    attributes.selectedValueIndex = pIndex;

    if (supportsDisplay(pHandlerInput) && !testingOnSim) {
        return bodyTemplateMaker('BodyTemplate3', pHandlerInput, pArray[pIndex].imageURL, capitalizeFirstLetter(pArray[pIndex].name), '<action value="read_info_token"><b>Read</b></action> | <action value="dictionary_token"><b>Back</b></action><br/>', pArray[pIndex].info, null, 'Here is some information about ' + pArray[pIndex].name + '.', null, 'test me on ' + categoryPlural, mainImgBlurBG, false);
    } else {
        var reprompt = 'Which ' + categorySingular + ' would you like to hear about now?';
        var speechOutput = pArray[pIndex].info + ' ' + reprompt;

        saveLastThingSaid(pHandlerInput, speechOutput);

        return response.speak(speechOutput).reprompt(reprompt).getResponse();
    }
}

function handleAnswer(pHandlerInput, pCorrectAnswer, pUserAnswer, pArray, pGameFinished) {
    var speechOutput;

    const attributes = pHandlerInput.attributesManager.getSessionAttributes();

    if (pCorrectAnswer == pUserAnswer) {
        //User answer is correct
        speechOutput = generateRandResponse(positiveSpeechconArray, true) + ' ' + generateRandResponse(correctResponses, false) + ' ';

        if (attributes.correctAnswersNo) {
            attributes.correctAnswersNo++;
        } else {
            attributes.correctAnswersNo = 1;
        }
    } else {
        //They are wrong
        speechOutput = generateRandResponse(negativeSpeechconArray, true) + ' ' + generateRandResponse(wrongResponses, false) + ' ';
    }

    if (!pGameFinished) {
        //Ask a new Q
        attributes.questionNumber++;
        return generateNewQuestion(pHandlerInput, speechOutput, attributes.questionNumber);
    } else {
        //Game over
        var answerSP = 'answers';
        var cardTitle = 'Game Over!';
        var gameoverImage;

        if (attributes.correctAnswersNo && attributes.correctAnswersNo == 1) {
            answerSP = 'answer'; //handle plural/singular
        }

        var correctAnswersVal = attributes.correctAnswersNo || 0;

        speechOutput += ' Out of ' + pArray.length + ', you got ' + correctAnswersVal + ' ' + answerSP + ' correct. ';
        var speechOutput2 = 'Ask to play again; otherwise, I can teach you about some of the penguins you have just seen if you would prefer. Just let me know.';
        speechOutput += speechOutput2;

        attributes.skillState = null;

        if (attributes.correctAnswersNo && attributes.correctAnswersNo > 4) {
            //Provide image based on score
            gameoverImage = firstPlaceImage;
        } else {
            gameoverImage = secondPlaceImage;
        }

        resetAttributes(pHandlerInput);

        if (supportsDisplay(pHandlerInput) && !testingOnSim) {

            var text = '<b><font size="7">' + correctAnswersVal + ' / ' + pArray.length + ' correct.</font></b>';
            return bodyTemplateMaker('BodyTemplate2', pHandlerInput, gameoverImage, cardTitle, text, '<br/>' + speechOutput2, null, speechOutput, null, "tell me about berries", mainImgBlurBG, false);

        } else {
            const response = pHandlerInput.responseBuilder;

            response.withShouldEndSession(null);

            saveLastThingSaid(pHandlerInput, speechOutput);

            return response.speak(speechOutput).getResponse();
        }
    }
}

function handleUnknown(pHandlerInput) {
    //For when Alexa doesn't understand the user
    var speechOutput = 'You can ask me to provide information, read the information to you, or take the quiz';
    var reprompt = 'Could you try again?';

    const response = pHandlerInput.responseBuilder;

    saveLastThingSaid(pHandlerInput, speechOutput);

    return response.speak(speechOutput).reprompt(reprompt).getResponse();
}

function endSkill(pHandlerInput) {
    var speechOutput = "Thanks for checking out " + skillName + ". Learn more about " + categoryPlural + " another time. Goodbye!"

    const response = pHandlerInput.responseBuilder;

    response.withShouldEndSession(true);

    return response
        .speak(speechOutput)
        .getResponse();
}

function generateNewQuestion(pHandlerInput, pSpeechOutput, pQuestionNo) {
    const attributes = pHandlerInput.attributesManager.getSessionAttributes();

    var objectArray = attributes.quizArray;
    var quizOptions = attributes.QuizOptionArray;
    var questionAskType = ['Which of these looks like ', 'Please select the image that represents ', 'Do you know which of these look like '];

    var question;
    question = 'Question ' + (pQuestionNo + 1) + ': ' + questionAskType[getRandomVal(0, 3)] + quizOptions[pQuestionNo].name + '?';
    attributes.storedQuestion = question;

    pSpeechOutput += question;
    var index;

    question = 'Question ' + (pQuestionNo + 1) + '/' + GAMELENGTH + ': ' + 'Which one looks like ' + quizOptions[pQuestionNo].name + '?';

    for (let i = 0; i < objectArray.length; i++) {
        //Find the correct index for the next question
        if (objectArray[i].name == quizOptions[pQuestionNo].name) {
            index = i;
            break;
        }
    }

    //Take it out of the main array
    objectArray.splice(index, 1);
    objectArray = shuffle(objectArray);

    //Add correct answer to new array
    var optionsArray = [quizOptions[pQuestionNo]];

    for (let i = 1; i < 4; i++)
        optionsArray[i] = objectArray[i]; //Add other random options to confuse user

    optionsArray = shuffle(optionsArray);

    for (let i = 0; i < optionsArray.length; i++) {
        if (optionsArray[i].name == quizOptions[pQuestionNo].name) {
            attributes.correctIndex = i; //Find the correct answer index and save for later
            break;
        }
    }

    attributes.onScreenOptions = optionsArray;
    attributes.questionNumber = pQuestionNo;

    pHandlerInput.attributesManager.setSessionAttributes(attributes);

    return listTemplateMaker('ListTemplate2', pHandlerInput, optionsArray, question, pSpeechOutput, true, mainImgBlurBG, true);
}

function listTemplateMaker(pListTemplateType, pHandlerInput, pArray, pTitle, pOutputSpeech, pQuiz, pBackgroundIMG, pQuiz) {
    const response = pHandlerInput.responseBuilder;
    const backgroundImage = imageMaker("", pBackgroundIMG);
    var itemList = [];
    var title = pTitle;
    var listItemNames = [];

    if (pQuiz)
    {
        for (var i = 0; i < pArray.length; i++) {
            listItemNames[i] = "";
        }
    }
    else
    {
        for (var i = 0; i < pArray.length; i++) {
            listItemNames[i] = pArray[i].name;
        }
    }



    for (var i = 0; i < pArray.length; i++) {
        itemList.push({
            "token": pArray[i].token,
            "textContent": new Alexa.PlainTextContentHelper().withPrimaryText(capitalizeFirstLetter(listItemNames[i])).getTextContent(),
            "image": imageMaker("", pArray[i].imageURL)
        });
    }

    if (pOutputSpeech) {
        response.speak(pOutputSpeech);
    }

    response.addRenderTemplateDirective({
        type: pListTemplateType,
        backButton: 'hidden',
        backgroundImage,
        title,
        listItems: itemList,
    });

    return response.getResponse();
}

function bodyTemplateMaker(pBodyTemplateType, pHandlerInput, pImg, pTitle, pText1, pText2, pText3, pOutputSpeech, pReprompt, pHint, pBackgroundIMG, pEndSession) {
    const response = pHandlerInput.responseBuilder;
    const image = imageMaker("", pImg);
    const richText = richTextMaker(pText1, pText2, pText3);
    const backgroundImage = imageMaker("", pBackgroundIMG);
    const title = pTitle;

    response.addRenderTemplateDirective({
        type: pBodyTemplateType,
        backButton: 'visible',
        image,
        backgroundImage,
        title,
        textContent: richText,
    });

    if (pHint)
        response.addHintDirective(pHint);

    if (pOutputSpeech)
        response.speak(pOutputSpeech);

    if (pReprompt)
        response.reprompt(pReprompt)

    if (pEndSession)
        response.withShouldEndSession(pEndSession);

    return response.getResponse();
}

function showMainList(pHandlerInput) //For main list of values in the dictionary
{
    var speechOutput;
    const attributes = pHandlerInput.attributesManager.getSessionAttributes();
    const response = pHandlerInput.responseBuilder;

    resetAttributes(pHandlerInput);

    if (supportsDisplay(pHandlerInput) && !testingOnSim) {
        speechOutput = 'Select or ask for a ' + categorySingular + ' below for more information.';

        return listTemplateMaker('ListTemplate1', pHandlerInput, attributes.mainArray, speechOutput, speechOutput, null, mainImgBlurBG, false);
    } else {
        var objectArray = attributes.mainArray;

        speechOutput = "I have a range of " + categoryPlural + " I can tell you about including: ";

        for (let i = 0; i < objectArray.length; i++)
            speechOutput += objectArray[i].name + ', ';

        speechOutput += "which would you like to hear about?";

        saveLastThingSaid(pHandlerInput, speechOutput)

        return response.speak(speechOutput).reprompt(speechOutput).getResponse();
    }
}

function imageMaker(pDesc, pSource) {
    const myImage = new Alexa.ImageHelper()
        .withDescription(pDesc)
        .addImageInstance(pSource)
        .getImage();

    return myImage;
}

function supportsDisplay(handlerInput) {
    var hasDisplay =
        handlerInput.requestEnvelope.context &&
        handlerInput.requestEnvelope.context.System &&
        handlerInput.requestEnvelope.context.System.device &&
        handlerInput.requestEnvelope.context.System.device.supportedInterfaces &&
        handlerInput.requestEnvelope.context.System.device.supportedInterfaces.Display
    return hasDisplay;
}

function resetAttributes(pHandlerInput) {
    const attributes = pHandlerInput.attributesManager.getSessionAttributes();
    attributes.skillState = null;
    attributes.selectedValueIndex = null;
    attributes.questionNumber = null;
    attributes.correctIndex = null;
    attributes.onScreenOptions = null;
    attributes.quizArray = null;
    attributes.QuizOptionArray = null;
    attributes.correctAnswersNo = null;
    attributes.storedQuestion = null;

    pHandlerInput.attributesManager.setSessionAttributes(attributes);
}

function saveLastThingSaid(pHandlerInput, pSpeechOutput) {
    const attributes = pHandlerInput.attributesManager.getSessionAttributes();
    attributes.lastOutputResponse = pSpeechOutput;
    pHandlerInput.attributesManager.setSessionAttributes(attributes);
}

function showSkillIntro(pSpeechOutput, pReprompt, pHandlerInput) {
    resetAttributes(pHandlerInput);

    var speechOutput = pSpeechOutput || '';
    var reprompt = pReprompt
    var cardTitle = skillName;

    speechOutput += 'Simply ask me to provide information about ' + categoryPlural + ' from the ' + skillDictionaryName + '.';

    if (supportsDisplay(pHandlerInput) && !testingOnSim) {

        //Selectable text
        var actionText1 = '<action value="dictionary_token"><i>' + skillDictionaryName + '</i></action>';
        var actionText2 = '<action value="quiz_token"><i>' + skillQuizName + '</i></action>';

        speechOutput += ' However, if you are feeling lucky, ask for a quick game of ' + skillQuizName + '.';
        saveLastThingSaid(pHandlerInput, speechOutput)

        var text = '<u><font size="7">' + skillName + '</font></u><br/><br/>Simply ask me to provide information about ' + categoryPlural + ' from the ' + actionText1 + '. However, if you are feeling lucky, ask for a quick game of ' + actionText2 + '.';
        return bodyTemplateMaker('BodyTemplate3', pHandlerInput, mainImage, cardTitle, text, null, null, speechOutput, reprompt, null, mainImgBlurBG, false);
    } else {
        const response = pHandlerInput.responseBuilder;

        saveLastThingSaid(pHandlerInput, speechOutput)

        return response
            .speak(speechOutput)
            .reprompt(reprompt)
            .getResponse();
    }
}

function newSessionHandler(pHandlerInput) //Called every intent to handle modal/one shot utterances
{
    if (pHandlerInput.requestEnvelope.session.new) {
        var topicNames = [];

        for (let i = 0; i < Object.keys(topicData).length; i++)
            topicNames[i] = Object.keys(topicData)[i];

        var categoryArray = [];

        for (let i = 0; i < Object.keys(topicData).length; i++) {
            //We create a new set of the specified category values here
            categoryArray[i] = createArrayValue(topicNames[i], topicData[topicNames[i]].imgURL, topicData[topicNames[i]].info);
        }

        const attributes = pHandlerInput.attributesManager.getSessionAttributes();

        attributes.mainArray = shuffle(categoryArray);
        pHandlerInput.attributesManager.setSessionAttributes(attributes);
    }
}

function richTextMaker(pPrimaryText, pSecondaryText, pTertiaryText) {
    const myTextContent = new Alexa.RichTextContentHelper();

    if (pPrimaryText)
        myTextContent.withPrimaryText(pPrimaryText);

    if (pSecondaryText)
        myTextContent.withSecondaryText(pSecondaryText);

    if (pTertiaryText)
        myTextContent.withTertiaryText(pTertiaryText);

    return myTextContent.getTextContent();
}

function plainTextMaker(pPrimaryText, pSecondaryText, pTertiaryText) {
    const myTextContent = new Alexa.PlainTextContentHelper()
        .withPrimaryText(pPrimaryText)
        .withSecondaryText(pSecondaryText)
        .withTertiaryText(pTertiaryText)
        .getTextContent();

    return myTextContent;
}